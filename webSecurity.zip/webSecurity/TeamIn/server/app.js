const express = require("express");
const app = express();
const path = require("path");
const bodyParser = require("body-parser");
const cors = require("cors");
const fs = require("fs");
const router = require("./routes/routing")
app.use(cors());

app.use(bodyParser.json());


app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "../views/index.html"));
});

app.get(/\.[A-z]{2,4}$/, (req, res) => {
    console.log(req.url);

    let url = path.join(__dirname, "../views", req.url);
    if (fs.existsSync(url))
        res.sendFile(url);
    else {
        res.end();
    }
});
app.use("/", router)
app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "../views/index.html"));
})



app.get("*", (req, res) => {
    res.send("You are navigating out of the application!");
});



app.listen(4800, () => {
    console.log("Server Running on Port 4800");
});