const express = require("express")
const employee = require("../employee.json")
const router = express.Router()


router.get("/employee/:empId", (req, res) => {
    let emp = null
    employee.forEach(element => {
        if (element.empId == req.params.empId)
            emp = element
    });

    emp ? res.status(200).send(emp) : res.status(404).send({message:"Details not found"})
})
router.get("/employee", (req, res) => {

    employee ? res.status(200).send(employee) : res.status(404).send({message:"Details not found"})
})

module.exports = router