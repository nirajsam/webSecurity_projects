const CACHE_STATIC_NAME = "pre-cache";
const Dynamic_cache = "dynamic-cache";

let cacheURL = [
    '/',
    'https://code.jquery.com/jquery-3.3.1.slim.min.js',
    'https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js',
    'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css',
    'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css',
    'style.css',
    'index.html',
    'contact.html',
    'main.js'
];
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_STATIC_NAME)
            .then((cache) => {
                console.log('[Service Worker] - Precaching app shell');
                cache.addAll(cacheURL);
            })
    );
});
self.addEventListener('activate', (event) => {
    console.log(`[Service worker] - ${event.type} service worker.... `);
    return self.clients.claim();
});
self.addEventListener('fetch', event => {
    console.log('Fetching from service worker ')
    event.respondWith(
        caches.match(event.request).then((response) => {
            if (response) {
                return response
            } else {
                return fetch(event.request).then((response) => {
                    return caches.open(Dynamic_cache).then((cache) => {
                        let responseToCache = response.clone()
                        cache.put(event.request, responseToCache)
                        return response
                    })
                })
            }
        })
    )
})
self.addEventListener("message", event => {
    self.skipWaiting()
})


